import { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import SceneManager from "./components/SceneManager";
import ManuscriptPage from "./components/ManuscriptPage";
import "./styles/retro.css";
import "./styles/manuscript.css";

function App() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Simple load delay to ensure everything is ready
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  if (!isLoaded) {
    return (
      <div className="loading-screen">
        <div className="loading-text">Loading...</div>
      </div>
    );
  }

  return (
    <div className="app">
      <Router>
        <Routes>
          <Route path="/" element={<SceneManager />} />
          <Route path="/manuscript/:philosopher" element={<ManuscriptPage />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
