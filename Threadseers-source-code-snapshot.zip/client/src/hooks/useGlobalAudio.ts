import { useRef, useEffect } from 'react';

let globalAudioInstance: HTMLAudioElement | null = null;
let isAudioInitialized = false;

export const useGlobalAudio = () => {
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const initializeAudio = () => {
    if (!globalAudioInstance && !isAudioInitialized) {
      isAudioInitialized = true;
      globalAudioInstance = new Audio('/sounds/ligo-waves.mp3');
      globalAudioInstance.loop = true;
      globalAudioInstance.volume = 0.2;
      
      // Handle audio load errors gracefully
      globalAudioInstance.onerror = () => {
        console.log('Global gravity wave audio could not load');
      };
    }
    audioRef.current = globalAudioInstance;
    return globalAudioInstance;
  };

  const playGlobalAudio = async () => {
    const audio = initializeAudio();
    if (audio && audio.paused) {
      try {
        await audio.play();
        console.log('Global gravity wave audio started');
      } catch (error) {
        console.log('Could not play global audio:', error);
      }
    }
  };

  const stopGlobalAudio = () => {
    if (globalAudioInstance && !globalAudioInstance.paused) {
      globalAudioInstance.pause();
      globalAudioInstance.currentTime = 0;
    }
  };

  const isPlaying = () => {
    return globalAudioInstance && !globalAudioInstance.paused;
  };

  return {
    playGlobalAudio,
    stopGlobalAudio,
    isPlaying,
    audioRef
  };
};