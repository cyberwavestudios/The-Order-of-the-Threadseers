import { useEffect, useRef, useCallback } from "react";

export const useAudioManager = () => {
  const textBlipRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Initialize audio
    textBlipRef.current = new Audio("/sounds/hit.mp3");
    textBlipRef.current.volume = 0.3;
  }, []);

  const playTextBlip = useCallback(() => {
    if (textBlipRef.current) {
      // Clone the audio to allow overlapping plays
      const audio = textBlipRef.current.cloneNode() as HTMLAudioElement;
      audio.volume = 0.1;
      audio.play().catch(() => {
        // Ignore play errors (common in browsers before user interaction)
      });
    }
  }, []);

  return { playTextBlip };
};
