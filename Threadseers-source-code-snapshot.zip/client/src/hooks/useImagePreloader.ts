import { useEffect, useState, useRef } from 'react';

export const useImagePreloader = (imageSrcs: string[]) => {
  const [isLoading, setIsLoading] = useState(true);
  const [loadedCount, setLoadedCount] = useState(0);
  const [hasError, setHasError] = useState(false);
  const isMountedRef = useRef(true);

  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    // Reset states when imageSrcs changes
    setIsLoading(true);
    setLoadedCount(0);
    setHasError(false);
    
    if (imageSrcs.length === 0) {
      if (isMountedRef.current) {
        setIsLoading(false);
      }
      return;
    }

    let loadedImages = 0;
    let hasErrorOccurred = false;
    const imageRefs: HTMLImageElement[] = [];

    const cacheImages = async (srcArray: string[]): Promise<void> => {
      const promises = srcArray.map((src) => {
        return new Promise<void>((resolve) => {
          const img = new Image();
          imageRefs.push(img);
          
          const cleanup = () => {
            img.onload = null;
            img.onerror = null;
          };
          
          img.onload = () => {
            if (isMountedRef.current) {
              loadedImages++;
              setLoadedCount(loadedImages);
            }
            cleanup();
            resolve();
          };
          
          img.onerror = (error) => {
            console.warn(`Failed to preload image: ${src}`, error);
            hasErrorOccurred = true;
            if (isMountedRef.current) {
              loadedImages++;
              setLoadedCount(loadedImages);
            }
            cleanup();
            resolve(); // Don't reject - continue loading other images
          };
          
          img.src = src;
        });
      });

      try {
        await Promise.all(promises);
        if (isMountedRef.current) {
          setHasError(hasErrorOccurred);
          setIsLoading(false);
        }
      } catch (error) {
        console.error('Image preloading failed:', error);
        if (isMountedRef.current) {
          setHasError(true);
          setIsLoading(false);
        }
      }
    };

    cacheImages(imageSrcs);

    // Cleanup function
    return () => {
      imageRefs.forEach(img => {
        img.onload = null;
        img.onerror = null;
      });
    };
  }, [imageSrcs]);

  return { 
    isLoading, 
    loadedCount, 
    totalCount: imageSrcs.length, 
    hasError,
    progress: imageSrcs.length > 0 ? (loadedCount / imageSrcs.length) * 100 : 100
  };
};