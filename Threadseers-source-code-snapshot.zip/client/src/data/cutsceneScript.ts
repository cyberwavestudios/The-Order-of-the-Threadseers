export interface Scene {
  id: string;
  title: string;
  background: string;
  chunks: string[];
}

export const cutsceneScript: Scene[] = [
  {
    id: "copernicus",
    title: "Copernicus",
    background: "copernicus-bg.svg",
    chunks: [
      "In a lonely tower at Frombork…\nBy candlelight, Copernicus traces the motions of planets.\nHe sees the heavens lurch and loop against the vault of night.",
      "The old order cannot explain it.\nThe Earth cannot be the center.\nThe Sun… must be.",
      "It is simple. It is terrifying.\nThe world does not revolve around man.\nMan drifts, small, in a turning cosmos.",
      "He hides it in his papers.\nOnly in death will his book be published.\nDe revolutionibus. The revolution of the spheres."
    ]
  },
  {
    id: "galileo",
    title: "Galileo",
    background: "galileo-bg.svg",
    chunks: [
      "Padua, a summer night.\nGalileo lifts a handmade telescope to the sky.\nThe Moon is scarred, mountainous. Not perfect, not divine.",
      "Jupiter carries moons of its own.\nOrbiting not Earth, but their master.\nThe heavens are rough. Dynamic. Alive.",
      "The Church condemns him.\nAccused of heresy, forced to kneel.\nHe abjures… but whispers truth:",
      "\"E pur si muove.\"\nAnd yet… it moves.",
      "Blind in his last years, under house arrest…\nYet mankind now has new eyes.\nAnd what they saw could not be unseen."
    ]
  },
  {
    id: "newton",
    title: "Newton",
    background: "newton-bg.svg",
    chunks: [
      "A plague drives Newton to solitude.\nHe sits alone at his family farm.\nAn apple falls.",
      "What force pulls it down?\nWhat holds the Moon to its path?",
      "He conjures a hidden thread.\nA force binding heaven and Earth.\nApple and orbit. Mortal and infinite.",
      "Principia Mathematica.\nA new cosmos where unseen force rules all.",
      "But Newton is haunted.\nBy prophecy, by alchemy, by fire.\nHe seeks the occult geometry of God's design.",
      "Gravity explained the apple's fall…\nBut not the meaning of existence."
    ]
  },
  {
    id: "bruno",
    title: "Bruno",
    background: "bruno-bg.svg",
    chunks: [
      "Venice cloisters. A night sky.\nWhere others saw stars… Bruno saw suns.\nEach with worlds innumerable.",
      "He proclaims an infinite universe.\nWithout center. Without boundary.",
      "The Inquisition seizes him.\nSeven years imprisoned.\nCondemned to the flames.",
      "Rome, Campo de' Fiori.\nFebruary morning.\nThe pyre is lit.",
      "\"Perhaps you, my judges, fear this sentence…\n…more than I fear receiving it.\"",
      "Bruno dies in fire.\nBut his vision of infinity cannot be destroyed."
    ]
  },
  {
    id: "threadseers",
    title: "Threadseer Revelation",
    background: "threadseer-bg.svg",
    chunks: [
      "But what if…\nTheir revelations were not sparks.\nBut fragments of a greater fire?",
      "What if Copernicus, Galileo, Newton, and Bruno…\nWere not just thinkers, but heralds?",
      "In another timeline… their legacies converge.\nA clandestine order is born.\nMathematicians. Mystics. Guardians.",
      "The Threadseers.",
      "They weave the fragments into one law.\nTime is orbital.\nSound becomes gravity.\nGravity becomes portal.",
      "The first Cybernetic Tuning-Fork is forged.\nAnd the first portal is sung open.",
      "Not to conquer space.\nBut to protect existence itself.",
      "Thus the Threadseers are born.\nHeirs of Copernicus, Galileo, Newton, and Bruno.\nGuardians of the weave of time."
    ]
  }
];
