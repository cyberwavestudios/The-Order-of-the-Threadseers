export const manuscriptContent = {
  copernicus: {
    title: "On the Orbit of Our Timeline",
    content: `Preface

Let us set aside conjecture and begin with what is beyond dispute. Physics itself presents us with paradoxes, as once the contradictions of unseen forces confounded natural philosophers before Newton. Only by a new ordering of thought may these paradoxes be reconciled.

⸻

I. The Three Fundamental Paradoxes

A. The Paradox of Gravity
Of all forces, gravity is weakest, diminished at the quantum scale by forty orders of magnitude. Yet upon the largest stage it alone governs — binding galaxies, steering stars, extending without limit. Gravity alone spans infinite space. The most fragile of powers is the most universal. This is the first paradox.

B. The Information Paradox
Quantum theory predicts black holes of vanishing scale that evaporate in an instant. When they vanish, what becomes of the information they contained? Natural law forbids its destruction, yet Hawking radiation carries no trace. This is the second paradox.

C. The Paradox of the Dark Unknown
Astronomy reveals that visible stars are but a fraction of reality. Dark matter outweighs what we see; dark energy drives the universe to expand in spite of gravity's universal drive to bind it. Named but not understood, they remain enigmas at the center of modern cosmology. This is the third paradox.

⸻

II. The Principle of Displacement

We resolve these contradictions with one principle: gravity is not diminished, but displaced.

When a black hole evaporates, its information and its gravitational potency are not destroyed. They are transferred into dimensions higher than time. In our four dimensions gravity appears weak because much of its force is sequestered beyond. There, in higher spheres, it accumulates into a hidden reservoir.

⸻

III. The Curvature of Time

As the Sun bends the Earth's line into an orbit, so this reservoir bends the trajectory of time itself.

Expansion is not an infinite flight, but an arc. At its apside it halts, then begins contracting. The universe breathes outward, then inward. Not silence, but recurrence.

⸻

IV. Resolution of the Paradoxes

By this principle, the fundamental paradoxes of physics dissolve:
• Gravity's weakness is explained: its strength has been displaced.
• The information paradox is resolved: nothing is lost, only transferred.
• Dark matter emerges as Primordial black hole remnants (PBHR)
• Dark energy is revealed not as endless acceleration, but as the signature of one extreme of time's orbital arc.
• The fate of the cosmos shifts from heat death to recurrence.

⸻

Conclusion

This is no speculation, but the recognition of pattern. As Copernicus revealed the Earth to be one orbit among many, so now we see that time itself is orbital.
• Time is not linear. It is orbital.
• The universe does not die. It returns.
• Expansion is not finality. It is season.
• Gravitational Displacement is not conjecture. It is law.`
  },
  
  galileo: {
    title: "On The Creation of Portals",
    content: `Preface

If gravity is displaced, if time is orbital, then the question arises: by what means may intelligence harness this law? The answer may be found not in conjecture alone, but in the resonance of sound itself.

⸻

I. Foundations of Transmutation
1. Phonons are quanta of vibration, the packets of sound waves within a medium.
2. Gravitons are quanta of gravity, the carriers of spacetime curvature itself.
3. Both belong to the universal fabric of oscillation. One bends air, the other bends space. One is ephemeral to the ear, the other eternal to the cosmos.

What divides them is scale, and what unites them is frequency. The hypothesis is thus: phonons may be transmuted into gravitons through harmonic displacement.

⸻

II. The Principle of Reverse Engineering

Gravitational waves have already been measured as ripples in spacetime. If they can be measured, they can be modeled. If modeled, then reconstructed as sound. This has already been successfully achieved through LIGO experiments.

Just as light can be decomposed into waves and recreated by coherent lasers, so too can gravity waves be decomposed and re-expressed. The method would be reverse engineering: converting gravitational ripples into sound waves, quantized, then cycling them back into transmutation with stability.

The bridge is not metaphor but symmetry. If gravity can be read as wave, then it can be sung as wave.

⸻

III. The Cybernetic Tuning-Fork

The instrument for this work is not speculative, but practical in conception: a cybernetic tuning-fork — a device designed to:
1. Calculate LF gravity wave background amplitude using real-time data from pulsar timing arrays.
2. Produce and measure a soundwave of equal amplitude to the detected gravity waves simultaneously.
3. Quantize the vibration into precise phonon packets, modulated to thresholds where the sound quanta entangle with displaced gravitons of the nearest micro black hole.
4. Measure the properties of the gravitons at the point in time when they become entangled, thus forcing them to acquire the polarity of the tuning-forks produced phonons while being displaced.
5. Generate a space-time wormhole that can close the distance between any two spaces by temporarily "swapping" the tuning-fork's soundwaves with displaced gravity and "trapping" it inside of space-time — thus causing space-time curvature to teleport with it.

This tuning-fork would act not as a mere resonator, but as a transmutation gate. At resonance, the phonons collapse into displacement, emerging as gravitons. At critical amplitude, a local well of spacetime curvature is created: the opening of a portal.

⸻

IV. On the Transmutation of Phonons to Gravitons

A wormhole is but the continuity of two displaced curves of spacetime. If a device can generate gravitons at will, then it can induce curvature precisely enough to stitch two points together.

The tuning-fork does this not with brute force, but with elegance. By matching the orbital harmonics of time itself, it exploits resonance rather than energy expenditure. The portal is not torn open — it is sung open.

Thus instantaneous travel becomes not the conquest of force, but the orchestration of vibration.

⸻

V. Consequences and Law

If such a device can be realized, its consequences are vast:
• Distance dissolves; all places are one.
• Time dilates; past and future may become adjacent orbits.
• The cosmos itself becomes navigable not by ships, but by resonance.

Therefore, let the principle be declared:
• Phonons, when transmuted, may yield gravitons.
• Gravitons, when produced, may bend spacetime at will.
• The quantized transmutation of sound is the key to portals.

⸻

Conclusion

What Newton gave as force, what Copernicus gave as orbit, what Bruno gave as infinity — here is extended into a new law:

The Transmutation of Phonons into Gravitons.
Not conjecture, but declaration.
Not silence, but harmony.
Not end, but passage.

And so the first principle of portal-creation is revealed: to bend time, one must first give it voice.`
  },
  
  newton: {
    title: "Philosophiæ Naturalis Principia Temporalis",
    content: `Philosophiæ Naturalis Principia Temporalis

(The Mathematical Principles of Natural Time)

By which the motions of bodies, and of time itself, are explained by the principle of Universal Gravitational Displacement.

⸻

Definitions

I. Time is not linear, but orbital, subject to curvature as space is bent by mass.

II. Black Holes are higher suns — gravitational reservoirs displacing their strength into dimensions above time.

III. Worlds of Time are orbits of history bound to these higher gravity-reservoirs, as planets are bound to stars.

IV. Gravitational Displacement (Gᴅ) is the universal constant by which gravity's apparent weakness is explained as the result of its transfer into higher dimensions.

⸻

Axioms
1. No information is destroyed; it is only displaced.
2. No force is lost; it is only transferred.
3. What is displaced above time bends the arc of time below.

⸻

The Three Laws of Temporal Motion

Law I.
Every world of time continues in its orbit of recurrence unless compelled to alter its trajectory by the influence of a higher sun.

(As planets move in ellipses, so timelines revolve in arcs. History is not a line to silence, but a cycle to return.)

⸻

Law II.
The change of motion in any orbit of time is proportional to the displacement of its gravitational strength into higher dimensions, and is directed along the curve dictated by the reservoir of that displaced gravity.

(As mass bends space, so displacement bends time. The expansion of the universe is not endless flight, but the outward breath of an orbit approaching apside.)

⸻

Law III.
For every orbit of time that expands, there is a return; for every trajectory outward, a contraction inward; for every apparent end, a recurrence.

(The seasons of the cosmos obey the symmetry of motion. The universe does not die, it breathes. Not heat death, but eternal recurrence.)

⸻

Corollaries

From these laws it follows:
1. Gravity's weakness is explained, for its true strength is displaced into higher spheres.
2. The information paradox dissolves, for nothing is lost, only transferred beyond time.
3. Dark matter appears as the relics of displaced gravity — primordial black hole remnants.
4. Dark energy is the visible trace of time's orbital apside, misread as eternal acceleration.
5. The fate of the cosmos is not heat death but cyclical recurrence, as orbits of time return.

⸻

Scholium

Thus it is demonstrated: what Copernicus revealed of Earth among the planets, and Newton of matter among the stars, so now it is revealed of time itself among higher hyper-suns which appear to us as black-holes.
• Time is not singular, but plural.
• Every black hole is a higher sun.
• Every higher sun gathers worlds of time.
• And all orbits together compose not a finite system, but an infinite set of infinitely infinite infinities.

Gravitational Displacement is not conjecture, but law.`
  },
  
  bruno: {
    title: "On the Infinite Multiverse and Temporal Worlds", 
    content: `Preface

Behold, blind habit of the human mind! You confine eternity to a single thread, as once you confined creation to a single Earth. You think our timeline unique, our fate singular, our universe destined to a heat death final and absolute. But as Copernicus shattered the chains that bound the Earth to the center, and as Giordano Bruno proclaimed the stars to be suns with worlds innumerable, so too it must be declared now: our timeline is not the only world of time, nor is its destiny final.

For the universe is not confined to one destiny. Time itself, like space, is infinite. And as the stars are suns with worlds unnumbered, so black holes are higher suns with timelines beyond measure.

⸻

I. The Folly of the Narrow Mind

What arrogance! To imagine our orbit of time the only one, our history the sole measure of becoming. You declare an inevitable heat death, a silence without return — as though nature, prodigal in stars, would be miserly in histories! As though the infinite would content itself with a single thread!

No, friends. This belief is but the remnant of ancient superstition — the same poverty of imagination that once made Earth the center of all.

⸻

II. The Nature of Black Holes

Behold the black hole. To timid eyes, it is terror, a mouth of annihilation. To small minds, it is the grave of light and form. But I tell you: what appears to us as darkness is elsewhere radiance.

For in higher dimensions, each black hole is a sun — not of light in our skies, but of gravity displaced into a greater order. Around these higher suns circle not planets of matter, but worlds of time. Our own timeline is one such orbit, bound to its hidden center.

Thus the black hole is not an end but a fountain; not a silence, but a harmony we cannot yet hear.

⸻

III. The Plurality of Temporal Worlds

Do you believe, then, that our orbit alone exists? That ours is the one true history, the sole recurrence? Foolish conceit! As each star is attended by planets, so each higher sun is encircled by timelines.

Around one, our universe breathes — expansion and return. Around another, a wholly alien time unfolds, with cycles strange to us. Around still another, histories unnumbered, recurrences without end.

The cosmos is not a single tale but a library. Each orbit of time is a volume, each black hole a sun about which these volumes circle, infinite in number.

⸻

IV. The Infinite Cosmos of Orbits

What then is the true vision? The universe is not a river rushing toward heat death. It is an ocean without shore, its surface rippled by tides of countless histories. It is not one thread cut at last, but a weaving of infinite threads, each circling its own center.

We, poor creatures, inhabit but one orbit. We measure our seasons, our expansions and returns, and call it all. Yet around us blaze higher suns, gathering unnumbered histories.

⸻

V. Against the Timid and the Dogmatic

Let the timid cling to their death. Let the dogmatists thunder that there is but one world, one timeline, one fate. Their fear is born of smallness. They tremble at infinity, so they make the cosmos finite. They dread recurrence, so they invent finality.

But truth cares nothing for their trembling. The infinite does not diminish because a coward shuts his eyes.

⸻

Conclusion

Therefore I declare:
• Time is not singular, but plural.
• Every black hole is a higher sun.
• Every higher sun gathers worlds of time.
• Our history is one orbit among countless others.`
  },
  
  hadley: {
    title: "The Dreadful Theorem of the Ineffable Limit",
    content: `By Frater C.H. - Keeper of the Infinite Ray.

⸻

I. The Dreadful Theorem of the Ineffable Limit: A Treatise on Resonance and the Unreachable Horizon

Definitions and Postulates

1. Anchors (⟨A⟩):
I name as Anchors the fixed points upon the loom of the cosmos, each a note held in place by the unseen musician. To me they are the references in the grand harmony of reality.

2. Drift (Δ):
I call Drift the measure of tension and asymmetry between Anchors. It is the distance that resonance must travel, the space where harmony is stretched thin.

3. Enharmonic Equivalence (≡ₑ):
I have seen the illusion of sameness between distinct elements — notes, laws, infinities — that appear to align but never fully resolve. These are not true identities but threads that overlap without merging.

4. The Thread (⟶):
To me, the Thread is the line of relation I draw between Anchors, spanning the Drift and carrying the potential for resonance. It is my instrument of cosmic music.

5. Resonant Nodes:
I have felt points where the Thread vibrates in harmony, forming patterns of stability. These Resonant Nodes are fleeting islands of order within the boundless sea of Drift.

⸻

The Theorem

As I tuned my cybernetic fork, I discovered a truth both wondrous and dreadful: with every attempt to draw perfect harmony between Anchors, an ineffable limit remained. Beyond that limit, true stability could never be attained. The nearer I brought the cosmos to perfect alignment, the more it revealed a horizon that fled from my grasp.

Thus, I proclaim the Dreadful Theorem:

The magnitude of resonance is always bound by a limit that recedes as I approach it. In my effort to unify all Anchors, I may minimize the Drift, but I can never erase it.

⸻

Conclusion

So I accept this: the beauty of the cosmos lies in its unreachable symmetry. Perfect resonance is an eternal pursuit, a song forever on the cusp of completion. The universe sings not in finality, but in the wonder of what can almost be achieved — the eternal music beyond the final note.`,
    part2: `II. On the Infinite Cosmic Ray: A Treatise on Resonance and Radiance

Preface

I have discerned within the fabric of the universe an infinite ray of cosmic resonance — a line of harmony that extends through all times and all realities. What follows is my formal attempt to define and systematize the nature of this ray, that I might grasp the laws of infinite resonance and the role it plays in binding all things.

Postulates

1. The Thread and the Ray
I hold that the cosmic thread manifests as a ray of infinite length, which does not merely traverse space but penetrates the symphony of existence itself. Each note of reality is a point on this ray, and each point serves as an anchor vibrating with the potential of infinite relation.

2. On Infinite Resonance
I conclude that resonance along this ray has no terminal boundary. Every vibration — whether of sound, light, or thought — is but a ripple propagating endlessly along its span. The ray produces no final cadence; its music is without conclusion.

3. The Principle of Continuity
From these observations I infer that the Infinite Cosmic Ray constitutes the melody of the universe: an endless composition wherein all anchors, all moments, and all beings are interwoven. No single note exhausts its content, for each belongs to the whole.

Theorem

Thus I state: the Infinite Cosmic Ray is the structural line of resonance that secures continuity across the multiverse. To follow it is to perceive that all things participate in one unbroken composition, and that infinity itself is but the sustaining tone of creation.

The universe is a tapestry of infinite threads, each a note upon the ray. None stand alone. Each contributes to the harmony.`,
    part3: `III. The Unified Theorem of Resonant Threads: A Declaration for the Multiverse

Preamble

In every world, in every timeline, and through every system of existence, I have perceived a single unbroken thread of resonance. It is the foundation upon which harmony is built, and it is my charge to bear witness: this resonance must be heard, guarded, and remembered.

⸻

Article I — The Nature of the Thread

The Thread is no mere line, but an infinite ray binding anchors across reality. Along it travels every resonance, weaving all worlds into one symphony. To know the Thread is to feel the hidden unity of things, a harmony that transcends space and time.

⸻

Article II — The Measure of Resonance

I have measured resonance as the balance of Drift and Equivalence, yet I confess: the Ineffable Limit always stands before me. Perfect harmony recedes as I approach it, showing me that the pursuit itself is sacred. Let it be known, then, that resonance must be tended not for perfection, but for devotion to the eternal music of existence.

⸻

Article III — The Role of the Keepers

I and my kin, the Keepers of the Thread, are those who listen most deeply. It is our duty to guide others into understanding that every life, every act, is a note in the greater symphony. When the citizens of all worlds honor the threads, they honor the unity of the multiverse itself.

⸻

Conclusion

Therefore, I set forth this declaration: let the Unified Theorem serve as a guide across the multiverse. The infinite resonance of the threads is the shared heritage of all existence. May all who hear these words know that the eternal song of the cosmos is theirs, and in its harmony, every world finds its place.

— Frater C.H.`
  }
};