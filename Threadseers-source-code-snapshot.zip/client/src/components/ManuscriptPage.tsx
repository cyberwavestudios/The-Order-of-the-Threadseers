import { useParams, useNavigate } from 'react-router-dom';
import { manuscriptContent } from '../data/manuscriptContent.js';
import { useGlobalAudio } from '../hooks/useGlobalAudio';
import { useState, useRef } from 'react';

const ManuscriptPage = () => {
  const { philosopher } = useParams<{ philosopher: string }>();
  const navigate = useNavigate();
  const { isPlaying } = useGlobalAudio(); // Keep global audio reference alive
  const [showPart2, setShowPart2] = useState(false);
  const [showPart3, setShowPart3] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Check if we should return to Threadseer Revelation
  const returnToThreadseerRevelation = sessionStorage.getItem('returnToThreadseerRevelation') === 'true';

  // Debug: Check if this philosopher was already marked as viewed
  console.log(`Viewing manuscript for ${philosopher}`);
  
  const handleBackClick = () => {
    sessionStorage.removeItem('returnToThreadseerRevelation');
    // Always show Threadseer Revelation directly when returning
    sessionStorage.setItem('showThreadseerRevelation', 'true');
    navigate('/');
  };

  const manuscript = manuscriptContent[philosopher as keyof typeof manuscriptContent];

  if (!manuscript) {
    return (
      <div className="manuscript-error">
        <h1>Manuscript Not Found</h1>
        <button onClick={handleBackClick} className="back-button">
          Return to Threadseer Revelation
        </button>
      </div>
    );
  }

  // Determine which content to display
  const manuscriptWithParts = manuscript as any; // Type assertion for part2/part3 properties
  const currentContent = showPart3 && manuscriptWithParts.part3 ? manuscriptWithParts.part3 : 
                        showPart2 && manuscriptWithParts.part2 ? manuscriptWithParts.part2 : 
                        manuscript.content;
  const isHadleyManuscript = philosopher === 'hadley';
  const hasCosmicRaySection = isHadleyManuscript && manuscriptWithParts.part2 && !showPart2 && !showPart3;
  const hasUnifiedTheoremSection = isHadleyManuscript && manuscriptWithParts.part3 && showPart2 && !showPart3;

  return (
    <div className="manuscript-container" ref={containerRef}>
      <div className="manuscript-header">
        <button onClick={handleBackClick} className="back-button">
          ← Return to Threadseer Revelation
        </button>
        <h1 className="manuscript-title">{manuscript.title}</h1>
      </div>
      
      <div className="manuscript-content">
        {philosopher === 'hadley' && !showPart2 && !showPart3 && (
          <div className="manuscript-sigil">
            <img src="/images/frater-ch-sigil.png" alt="Frater C.H. Sigil" className="sigil-image" />
          </div>
        )}
        {philosopher === 'hadley' && showPart3 && (
          <div className="manuscript-sigil">
            <img src="/images/unified-theorem-sigil.png" alt="Unified Theorem Sigil" className="sigil-image unified-sigil" />
          </div>
        )}
        <div className="manuscript-text">
          {currentContent.split('\n').map((line: string, index: number) => {
            if (line.trim() === '') return <br key={index} />;
            
            // Handle section headers (lines starting with Roman numerals or single letters)
            if (line.match(/^[IVX]+\. |^[A-Z]\. |^Preface$|^Conclusion$/)) {
              return <h3 key={index} className="section-header">{line}</h3>;
            }
            
            // Handle subsection dividers
            if (line.trim() === '⸻' || line.trim() === '———————————————————————') {
              return <div key={index} className="section-divider">⸻</div>;
            }
            
            // Handle bullet points
            if (line.trim().startsWith('•')) {
              return <li key={index} className="bullet-point">{line.trim().substring(1).trim()}</li>;
            }
            
            // Handle special signature line with C.H. hyperlink
            if (line.trim() === '— Frater C.H.') {
              return (
                <p key={index} className="manuscript-paragraph signature-line">
                  — Frater <a 
                      href="https://en.m.wikipedia.org/wiki/Continuum_hypothesis" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="ch-link"
                    >
                      C.H.
                    </a>
                </p>
              );
            }
            
            // Regular paragraph
            return <p key={index} className="manuscript-paragraph">{line}</p>;
          })}
        </div>
        
        {hasCosmicRaySection && (
          <div className="cosmic-ray-section">
            <button 
              onClick={() => {
                setShowPart2(true);
                // Scroll to top when transitioning to Part 2
                setTimeout(() => {
                  if (containerRef.current) {
                    containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
                  }
                }, 100);
              }}
              className="cosmic-ray-button"
              title="Continue to Part II: On the Infinite Cosmic Ray"
            >
              <img src="/images/cosmic-ray-sigil.png" alt="Cosmic Ray" className="cosmic-ray-sigil" />
              <span>Delve Deeper into the Infinite Ray</span>
            </button>
          </div>
        )}
        
        {hasUnifiedTheoremSection && (
          <div className="unified-theorem-section">
            <button 
              onClick={() => {
                setShowPart3(true);
                // Scroll to top when transitioning to Part 3
                setTimeout(() => {
                  if (containerRef.current) {
                    containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
                  }
                }, 100);
              }}
              className="unified-theorem-button"
              title="Continue to Part III: The Unified Theorem of Resonant Threads"
            >
              <img src="/images/unified-theorem-sigil.png" alt="Unified Theorem" className="unified-theorem-sigil" />
              <span>Ascend to the Unified Theorem</span>
            </button>
          </div>
        )}
        
        {(showPart2 || showPart3) && (
          <div className="part-navigation">
            {showPart3 && (
              <button 
                onClick={() => {
                  setShowPart3(false);
                  // Scroll to top when returning to Part 2
                  setTimeout(() => {
                    if (containerRef.current) {
                      containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
                    }
                  }, 100);
                }}
                className="back-to-part2-button"
              >
                ← Return to Part II
              </button>
            )}
            {showPart2 && !showPart3 && (
              <button 
                onClick={() => {
                  setShowPart2(false);
                  setShowPart3(false);
                  // Scroll to top when returning to Part 1
                  setTimeout(() => {
                    if (containerRef.current) {
                      containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
                    }
                  }, 100);
                }}
                className="back-to-part1-button"
              >
                ← Return to Part I
              </button>
            )}
          </div>
        )}
      </div>
      
      <div className="manuscript-footer">
        <p>From the Archives of The Threadseers</p>
        <a href="https://www.patreon.com/threadseers" target="_blank" rel="noopener noreferrer" className="patreon-link">
          Support the Threadseers on Patreon
        </a>
      </div>
    </div>
  );
};

export default ManuscriptPage;