import { useState, useEffect } from "react";

interface DialogueBoxProps {
  text: string;
  onComplete: () => void;
}

const DialogueBox = ({ text, onComplete }: DialogueBoxProps) => {
  const [showText, setShowText] = useState(false);

  useEffect(() => {
    setShowText(false);
    const timer = setTimeout(() => setShowText(true), 50);
    return () => clearTimeout(timer);
  }, [text]);

  return (
    <div className="dialogue-box">
      <div className="dialogue-content">
        <div className={`dialogue-text ${showText ? 'fade-in' : ''}`}>
          {text}
        </div>
      </div>
      
      <div className="advance-indicator">
        <span className="advance-arrow">▼</span>
      </div>
    </div>
  );
};

export default DialogueBox;
