import { useEffect, useRef, useState } from "react";
import { type Scene } from "../data/cutsceneScript";

interface CutsceneCanvasProps {
  scene: Scene;
  isTransitioning: boolean;
  showSeal: boolean;
}

function loadCharacterImages() {
  const images: {[key: string]: HTMLImageElement} = {};
  const sprites = {
    'copernicus': '/images/copernicus-sprite.png',
    'galileo': '/images/galileo-sprite.png',
    'newton': '/images/newton-sprite.png',
    'bruno': '/images/bruno-sprite.png'
  };

  Object.entries(sprites).forEach(([key, src]) => {
    const img = new Image();
    img.src = src;
    images[key] = img;
  });

  return images;
}

const CutsceneCanvas = ({ scene, isTransitioning, showSeal }: CutsceneCanvasProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stars] = useState(() => generateStars());
  const [characterImages] = useState(() => loadCharacterImages());

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // Animation loop
    let animationId: number;
    let time = 0;

    const animate = () => {
      time += 0.016; // ~60fps
      
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Draw cosmic background
      drawCosmicBackground(ctx, canvas.width, canvas.height, time);
      
      // Draw stars
      drawStars(ctx, stars, time);
      
      // Draw scene-specific background
      if (!showSeal) {
        drawSceneBackground(ctx, scene, canvas.width, canvas.height, characterImages);
      }
      
      // Draw transition overlay
      if (isTransitioning) {
        drawTransitionOverlay(ctx, canvas.width, canvas.height);
      }

      // Draw CRT effect
      drawCRTEffect(ctx, canvas.width, canvas.height, time);
      
      animationId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener("resize", resizeCanvas);
      cancelAnimationFrame(animationId);
    };
  }, [scene, isTransitioning, showSeal, stars, characterImages]);

  return <canvas ref={canvasRef} className="cutscene-canvas" />;
};

function generateStars() {
  const stars = [];
  for (let i = 0; i < 200; i++) {
    stars.push({
      x: Math.random(),
      y: Math.random(),
      brightness: Math.random(),
      twinkleSpeed: 0.5 + Math.random() * 2,
    });
  }
  return stars;
}

function drawCosmicBackground(ctx: CanvasRenderingContext2D, width: number, height: number, time: number) {
  // Create cosmic gradient
  const gradient = ctx.createRadialGradient(width / 2, height / 2, 0, width / 2, height / 2, Math.max(width, height));
  gradient.addColorStop(0, "#0a0a1a");
  gradient.addColorStop(0.5, "#1a0a2e");
  gradient.addColorStop(1, "#0f0f23");
  
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);
}

function drawStars(ctx: CanvasRenderingContext2D, stars: any[], time: number) {
  stars.forEach(star => {
    const x = star.x * ctx.canvas.width;
    const y = star.y * ctx.canvas.height;
    const brightness = star.brightness * (0.5 + 0.5 * Math.sin(time * star.twinkleSpeed));
    
    ctx.fillStyle = `rgba(255, 255, 255, ${brightness})`;
    ctx.fillRect(x, y, 2, 2);
  });
}

function drawSceneBackground(ctx: CanvasRenderingContext2D, scene: Scene, width: number, height: number, characterImages: {[key: string]: HTMLImageElement}) {
  // Draw character sprite
  const spriteKey = scene.id;
  const characterImg = characterImages[spriteKey];
  
  if (characterImg && characterImg.complete) {
    const spriteSize = 180;
    const x = width / 2 - spriteSize / 2;
    const y = height / 2 - spriteSize / 2 - 60; // Position above dialogue box
    
    // Add glow effect
    ctx.shadowColor = "#00ff00";
    ctx.shadowBlur = 15;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
    
    ctx.drawImage(characterImg, x, y, spriteSize, spriteSize);
    
    // Reset shadow
    ctx.shadowBlur = 0;
  }
  
  // Draw scene title
  ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
  ctx.font = "28px 'JetBrains Mono', monospace";
  ctx.textAlign = "center";
  ctx.strokeStyle = "rgba(0, 0, 0, 0.8)";
  ctx.lineWidth = 2;
  ctx.strokeText(scene.title, width / 2, 80);
  ctx.fillText(scene.title, width / 2, 80);
}

function drawTransitionOverlay(ctx: CanvasRenderingContext2D, width: number, height: number) {
  ctx.fillStyle = "rgba(0, 0, 0, 0.8)";
  ctx.fillRect(0, 0, width, height);
}

function drawCRTEffect(ctx: CanvasRenderingContext2D, width: number, height: number, time: number) {
  // Draw scanlines
  ctx.fillStyle = "rgba(0, 0, 0, 0.1)";
  for (let y = 0; y < height; y += 4) {
    ctx.fillRect(0, y, width, 2);
  }
  
  // Draw subtle flicker
  const flicker = 0.98 + 0.02 * Math.sin(time * 60);
  ctx.fillStyle = `rgba(255, 255, 255, ${1 - flicker})`;
  ctx.fillRect(0, 0, width, height);
}

export default CutsceneCanvas;
