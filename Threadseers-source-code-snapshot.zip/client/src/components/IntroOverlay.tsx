import { useMemo } from 'react';
import { useImagePreloader } from '../hooks/useImagePreloader';

interface IntroOverlayProps {
  onEnterExperience: () => void;
  onPatreonClick: () => void;
}

const IntroOverlay = ({ onEnterExperience, onPatreonClick }: IntroOverlayProps) => {
  // Preload all RPG experience images (memoized to prevent re-triggers)
  const rpgImages = useMemo(() => [
    // Character sprites for cutscenes
    '/images/copernicus-sprite.png',
    '/images/galileo-sprite.png', 
    '/images/newton-sprite.png',
    '/images/bruno-sprite.png',
    // Scene images
    '/images/cosmic-truth.png',
    '/images/cyber-tuning-fork.png',
    '/images/threadseer-seal.png',
    '/images/threadseer-codex.png'
  ], []);
  
  const { isLoading: imagesLoading, progress: imageProgress, hasError: imageError } = useImagePreloader(rpgImages);

  const handleEnterClick = () => {
    // Don't proceed if images are still loading
    if (imagesLoading) {
      return;
    }
    onEnterExperience();
  };

  return (
    <div className="intro-overlay">
      <div className="intro-content">
        <div className="intro-title">
          <h1>The Order of the Threadseers</h1>
          <p>A retro RPG cutscene experience</p>
        </div>
        
        {/* Loading progress indicator */}
        {imagesLoading && (
          <div className="loading-progress">
            <div className="loading-text">Preparing RPG assets...</div>
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${imageProgress}%` }}
              ></div>
            </div>
            <div className="progress-text">{Math.round(imageProgress)}%</div>
          </div>
        )}
        
        {/* Error indicator for failed assets */}
        {!imagesLoading && imageError && (
          <div className="loading-error">
            ⚠️ Some assets failed to load. Experience may be degraded but is still playable.
          </div>
        )}
        
        <div className="intro-buttons">
          <button 
            className={`enter-button ${imagesLoading ? 'loading' : ''}`}
            onClick={handleEnterClick}
            onTouchEnd={(e) => { e.preventDefault(); handleEnterClick(); }}
            disabled={imagesLoading}
          >
            {imagesLoading ? 'Loading...' : 'Γνῶθι σεαυτόν'}
          </button>
          
          <button 
            className="patreon-button"
            onClick={onPatreonClick}
            onTouchEnd={(e) => { e.preventDefault(); onPatreonClick(); }}
          >
            join the resistance
          </button>
        </div>
      </div>
    </div>
  );
};

export default IntroOverlay;