import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import CutsceneCanvas from "./CutsceneCanvas";
import DialogueBox from "./DialogueBox";
import IntroOverlay from "./IntroOverlay";
import { cutsceneScript, type Scene } from "../data/cutsceneScript";
import { useGlobalAudio } from '../hooks/useGlobalAudio';


const SceneManager = () => {
  const navigate = useNavigate();
  const [currentSceneIndex, setCurrentSceneIndex] = useState(0);
  const [currentChunkIndex, setCurrentChunkIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [showSeal, setShowSeal] = useState(false);
  const [showTuningFork, setShowTuningFork] = useState(false);
  const [showIntro, setShowIntro] = useState(() => {
    // Only show intro if it hasn't been completed in this session
    return !sessionStorage.getItem('introCompleted');
  });
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { playGlobalAudio, isPlaying } = useGlobalAudio();

  // Handle intro screen - enables audio on mobile
  const handleEnterExperience = async () => {
    // Try to initialize audio context on user interaction
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      if (audioContext.state === 'suspended') {
        await audioContext.resume();
      }
    } catch (e) {
      console.log('Audio context initialization skipped:', e);
    }
    // Mark intro as completed for this session
    sessionStorage.setItem('introCompleted', 'true');
    setShowIntro(false);
  };
  
  const handlePatreonClick = () => {
    window.open('https://www.patreon.com/CyberwaveResistanceNetwork?utm_campaign=creatorshare_creator', '_blank');
  };
  
  // Progress tracking for manuscript views - start with empty state, load in useEffect
  const [viewedManuscripts, setViewedManuscripts] = useState<Set<string>>(new Set());

  const markAsViewed = (philosopher: string) => {
    // Always load current progress from localStorage to ensure we're accumulating correctly
    let currentViewed = new Set<string>();
    try {
      const stored = localStorage.getItem('viewedManuscripts');
      if (stored) {
        const storedArray: string[] = JSON.parse(stored);
        currentViewed = new Set<string>(storedArray);
      }
    } catch {
      currentViewed = new Set<string>();
    }
    
    // Add this philosopher to the set
    currentViewed.add(philosopher);
    
    // Update both state and localStorage
    setViewedManuscripts(currentViewed);
    localStorage.setItem('viewedManuscripts', JSON.stringify(Array.from(currentViewed)));
    console.log(`Marked ${philosopher} as viewed. Total viewed:`, Array.from(currentViewed));
  };

  const allManuscriptsViewed = ['copernicus', 'galileo', 'newton', 'bruno'].every(id => viewedManuscripts.has(id));

  // Global gravitational wave audio - plays eternally once triggered
  useEffect(() => {
    if (showSeal) {
      // Start the eternal gravity wave audio as soon as philosopher names appear
      playGlobalAudio();
    }
  }, [showSeal, playGlobalAudio]);

  const navigateToManuscript = useCallback((philosopher: string) => {
    markAsViewed(philosopher);
    // Store that we came from threadseer revelation
    sessionStorage.setItem('returnToThreadseerRevelation', 'true');
    navigate(`/manuscript/${philosopher}`);
  }, [navigate]);

  useEffect(() => {
    audioRef.current = new Audio("/sounds/hit.mp3");
    audioRef.current.volume = 0.4;
    
    // Check if we should show Threadseer Revelation immediately (coming back from manuscript)
    const shouldShowRevelation = sessionStorage.getItem('showThreadseerRevelation') === 'true';
    
    if (shouldShowRevelation) {
      sessionStorage.removeItem('showThreadseerRevelation');
      // Load existing progress when returning from manuscript
      try {
        const stored = localStorage.getItem('viewedManuscripts');
        const storedArray = stored ? JSON.parse(stored) : [];
        setViewedManuscripts(new Set(storedArray));
        console.log('Loaded existing progress:', storedArray);
      } catch {
        setViewedManuscripts(new Set());
      }
      // Immediately show the seal without scene transition
      setTimeout(() => {
        setCurrentSceneIndex(cutsceneScript.length - 1);
        setCurrentChunkIndex(cutsceneScript[cutsceneScript.length - 1].chunks.length - 1);
        setShowSeal(true);
      }, 50);
    } else {
      // Fresh start - clear all progress
      localStorage.removeItem('viewedManuscripts');
      setViewedManuscripts(new Set());
      console.log('Fresh start - progress cleared');
    }
  }, []);

  const currentScene = cutsceneScript[currentSceneIndex];
  const isLastScene = currentSceneIndex === cutsceneScript.length - 1;
  const isLastChunk = currentChunkIndex === currentScene.chunks.length - 1;

  const handleAdvance = useCallback(() => {
    if (isTransitioning) return;

    // Play blip sound
    if (audioRef.current) {
      const audio = audioRef.current.cloneNode() as HTMLAudioElement;
      audio.volume = 0.3;
      audio.play().catch(() => {});
    }

    if (isLastChunk) {
      if (isLastScene) {
        // Show the Cybernetic Tuning-Fork intermediate page
        setShowTuningFork(true);
        return;
      } else {
        // Transition to next scene
        setIsTransitioning(true);
        setTimeout(() => {
          setCurrentSceneIndex(prev => prev + 1);
          setCurrentChunkIndex(0);
          setIsTransitioning(false);
        }, 1000);
      }
    } else {
      // Advance to next chunk
      setCurrentChunkIndex(prev => prev + 1);
    }
  }, [isLastChunk, isLastScene, isTransitioning]);

  const handleKeyPress = useCallback((event: KeyboardEvent) => {
    if (event.key === 'Enter' || event.key === ' ' || event.key === 'z' || event.key === 'Z') {
      event.preventDefault();
      handleAdvance();
    }
  }, [handleAdvance]);

  const handleClick = useCallback((event: MouseEvent | TouchEvent) => {
    event.preventDefault();
    handleAdvance();
  }, [handleAdvance]);

  const handleTuningForkClick = () => {
    window.open('https://cybernetic-tuner.cyberwavestudios.com', '_blank');
  };

  const handleProceedToManuscripts = () => {
    setShowTuningFork(false);
    setShowSeal(true);
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyPress);
    window.addEventListener('click', handleClick);
    window.addEventListener('touchend', handleClick);
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
      window.removeEventListener('click', handleClick);
      window.removeEventListener('touchend', handleClick);
    };
  }, [handleKeyPress, handleClick]);

  const currentChunk = currentScene.chunks[currentChunkIndex];

  // Show intro screen first
  if (showIntro) {
    return (
      <IntroOverlay 
        onEnterExperience={handleEnterExperience}
        onPatreonClick={handlePatreonClick}
      />
    );
  }

  return (
    <div className="scene-manager">
      <CutsceneCanvas 
        scene={currentScene}
        isTransitioning={isTransitioning}
        showSeal={showSeal}
      />
      
      {/* Cosmic truth image for Threadseer Revelation scene */}
      {!showSeal && !showTuningFork && currentScene.id === "threadseers" && (
        <div className="cosmic-truth">
          <img src="/images/cosmic-truth.png" alt="Cosmic Truth" />
        </div>
      )}

      {!showSeal && !showTuningFork && (
        <DialogueBox
          text={currentChunk}
          onComplete={() => {}}
          key={`${currentSceneIndex}-${currentChunkIndex}`}
        />
      )}

      {showTuningFork && (
        <div className="tuning-fork-container">
          <div className="tuning-fork-content">
            <h1 className="tuning-fork-title">The Cybernetic Tuning-Fork</h1>
            <p className="tuning-fork-description">
              "A device that quantizes vibration, entangles it with displaced gravitons, and bends spacetime itself into continuity."
            </p>
            
            <div className="tuning-fork-image-container">
              <img 
                src="/images/cyber-tuning-fork.png" 
                alt="Cybernetic Tuning-Fork" 
                className="tuning-fork-image"
                onClick={handleTuningForkClick}
                onTouchEnd={(e) => { e.preventDefault(); handleTuningForkClick(); }}
              />
            </div>
            
            <div className="tuning-fork-actions">
              <button 
                className="tuning-fork-button"
                onClick={handleTuningForkClick}
                onTouchEnd={(e) => { e.preventDefault(); handleTuningForkClick(); }}
              >
                🎵 Experience the Graviton Tuner
              </button>
              
              <button 
                className="proceed-button"
                onClick={handleProceedToManuscripts}
                onTouchEnd={(e) => { e.preventDefault(); handleProceedToManuscripts(); }}
              >
                Continue to the Manuscripts →
              </button>
            </div>
          </div>
        </div>
      )}

      {showSeal && (
        <div className="threadseer-seal-container">
          {/* Mystical codex image */}
          <div className="threadseer-codex">
            <img src="/images/threadseer-codex.png" alt="Threadseer Codex" />
          </div>
          
          {/* Subtle progress indicator */}
          <div className="progress-indicator">
            {Array.from({length: 4}, (_, i) => (
              <div 
                key={i} 
                className={`progress-dot ${viewedManuscripts.has(['copernicus', 'galileo', 'newton', 'bruno'][i]) ? 'viewed' : ''}`}
              />
            ))}
          </div>
          
          {allManuscriptsViewed && (
            <div className="ligo-indicator">
              🌊 LIGO Gravitational Waves Detected 🌊
            </div>
          )}
          
          <div className="seal-animation">
            <div 
              className="seal-link"
              onClick={() => window.open("https://www.patreon.com/CyberwaveResistanceNetwork?utm_campaign=creatorshare_creator", "_blank")}
              onTouchEnd={(e) => { e.preventDefault(); window.open("https://www.patreon.com/CyberwaveResistanceNetwork?utm_campaign=creatorshare_creator", "_blank"); }}
              role="button"
              tabIndex={0}
            >
              <img src="/images/threadseer-seal.png" alt="Official Threadseer Seal" />
            </div>
          </div>
          <div className="creed-text">
            <h2>The Threadseers</h2>
            <p>Heirs of <span 
              className="philosopher-link" 
              onClick={() => navigateToManuscript('copernicus')}
              onTouchEnd={(e) => { e.preventDefault(); navigateToManuscript('copernicus'); }}
            >Copernicus</span>, <span 
              className="philosopher-link" 
              onClick={() => navigateToManuscript('galileo')}
              onTouchEnd={(e) => { e.preventDefault(); navigateToManuscript('galileo'); }}
            >Galileo</span>, <span 
              className="philosopher-link" 
              onClick={() => navigateToManuscript('newton')}
              onTouchEnd={(e) => { e.preventDefault(); navigateToManuscript('newton'); }}
            >Newton</span>, and <span 
              className="philosopher-link" 
              onClick={() => navigateToManuscript('bruno')}
              onTouchEnd={(e) => { e.preventDefault(); navigateToManuscript('bruno'); }}
            >Bruno</span>.</p>
            <p>Guardians of the weave of time.</p>
            
            {allManuscriptsViewed && (
              <div className="secret-reveal">
                <h3>The Complete Revelation</h3>
                <p>What if the revelations of our four esteemed natural philosophers were not isolated sparks, but fragments of a greater fire?</p>
                <p>What if Copernicus, Galileo, Newton, and Bruno were not only thinkers, but precursors — heralds of a deeper law yet unfinished?</p>
                <p>And what if there emerged a fifth voice, <span 
                  className="philosopher-link" 
                  onClick={() => navigateToManuscript('hadley')}
                  onTouchEnd={(e) => { e.preventDefault(); navigateToManuscript('hadley'); }}
                >Frater C.H.</span>, who would compose the final eulogy for the pride of intellect itself?</p>
                <p>In one timeline, our timeline, their works end as history records: Copernicus shamed, Galileo silenced, Newton haunted, Bruno condemned. But in another — an alternate recurrence — their legacies converge.</p>
                <p>In that world - Timeline 33C - a school arises. A clandestine order neither church nor state, but something older and bolder: the Threadseers. Mathematicians and mystics, physicists and philosophers, they inherit the fragments of the four revelations and weave them into one tapestry.</p>
                <ul className="secret-list">
                  <li>From Copernicus, they inherit the orbital revolution: just as the Earth revolves around a celestial body with a greater mass — so too does time itself. Time is not the center of temporality - it is orbital.</li>
                  <li>From Galileo, they inherit resonance: vibration is the universal key, the bridge between matter, motion, and recurrence.</li>
                  <li>From Newton, they inherit gravity and take it to its conclusion, formulating the new constant of gravitational displacement (Gd): the fuel for the massive hidden reservoir above space-time which bends each timeline orbiting around it.</li>
                  <li>From Bruno, they inherit infinity: not only infinite worlds in space, but infinite orbits of time, histories spiraling endlessly around higher masses of gravity.</li>
                </ul>
                <p>Together, they resolve the paradoxes that divided physics. They declare the New Law of Phonon–Graviton Transmutation: that sound may collapse into gravity, and gravity may be sung into portals.</p>
                <p>And with this law they build the first Cybernetic Tuning-Fork: a device that quantizes vibration, entangles it with displaced gravitons, and bends spacetime itself into continuity.</p>
                <p>With it, they open the first portal. Not to conquer space, but to protect existence itself. For if space-time can be manipulated it can be fractured. And if it can be fractured, then guardians are needed — those who can weave the threads back together.</p>
                <p>Thus the Threadseers are born: heirs of Copernicus, Galileo, Newton, and Bruno. And though we may be tempted to take the story of The Threadseers as myth from the perspective of our timeline, it may prove useful to know that the citizens of their own Timeline tend to have the same opinion of them. Nevertheless, in their universe, their task is clear:</p>
                <p className="final-declaration">to complete the work of the great philosophers, to safeguard the weave of time, and to bend it not with violence, but with harmony.</p>
                
                <div className="threadseer-links">
                  <h4>Continue Your Journey Through the Threads</h4>
                  <button 
                    className="threadseer-app-link"
                    onClick={() => window.open('https://universal-time.cyberwavestudios.com', '_blank')}
                    onTouchEnd={(e) => { e.preventDefault(); window.open('https://universal-time.cyberwavestudios.com', '_blank'); }}
                  >
                    🌌 Universal Thread of Time
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="controls-hint">
        Press ENTER, SPACE, Z or TAP to advance
      </div>
    </div>
  );
};

export default SceneManager;
